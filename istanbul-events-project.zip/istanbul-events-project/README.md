# Istanbul Events Tracker

Two versions of the tracker are included:

- **app.html** — the full functional app: shared/persistent event board (via the
  Claude artifact `window.storage` API), add/edit/delete events, live-updating
  countdowns, search/filter/sort. This one only runs correctly inside a Claude.ai
  artifact (it depends on `window.storage`, which isn't available in a plain browser).
- **static-tracker.html** — a standalone, no-dependency version with the same
  design and curated event list, but no persistence/editing. Open this directly
  in any browser — no special environment needed.

## Data
Events cover Istanbul startups, medical devices/clinics, and AI, current as of
July 12, 2026. Sources and fee notes are inside each card and in the "Keep this
truly real-time" section of the app.

## Notes
- app.html's shared board only works when opened as a Claude artifact — outside
  that environment, storage calls will fail gracefully but adding/editing won't persist.
- To keep this current, either re-ask Claude to refresh it, or hand-edit the
  `seedEvents` array in either file.
